from django.contrib import admin
from .models import *

class GoodsAdmin(admin.ModelAdmin):
#     指定在类表中显示的字段
    list_display = ('title','goodstype','price','spec')
#     指定右侧显示的过滤器
    list_filter = ('goodstype',)
#      指定上方搜索的字段们
    search_fields = ('title',)
# Register your models here.
admin.site.register(GoodsType)
admin.site.register(Goods,GoodsAdmin)



