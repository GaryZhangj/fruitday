from django.core import serializers
from django.shortcuts import render, redirect
import json

from .models import *
from django.http import HttpResponse, HttpResponseRedirect
from .forms import *
# Create your views here.

def login_views(request):
    # 判断是get还是post
    if request.method == 'GET':
    #     获取来访地址如果没有则设置为/
        url = request.META.get('HTTP_REFERER','/')
    #     先判断session中是否有登录信息
        if 'uid' in request.session and 'uphone' in request.session:
    #         有登陆信息在session'中
    #         从哪来 回哪去
            resp = HttpResponseRedirect(url)
            return resp
        else:
            # 没有信息 判断cookies中是否有登录信息
            if 'uid' in request.COOKIES and 'uphone' in request.COOKIES:
                # 有登录记录
            #     将cookies中的信息取出来保存进session返回首页
                uid = request.COOKIES['uid']
                uphone = request.COOKIES['uphone']
                request.session['uid']=uid
                request.session['uphone']=uphone
                # 从哪来 回哪去
                resp = HttpResponseRedirect(url)
                return resp

            else:
    #             cookies没有登录信息去往登录页
                form = LoginFrom()
                # 将来访地址保存在cookies
                resp = render(request,'login.html',locals())
                resp.set_cookie('url',url)
                return resp




    else:
        # post请求实现登录操作
        # 获取手机号和密码
        uphone = request.POST['uphone']
        upwd = request.POST['upwd']
        # 判断手机号和密码是否存在登录是否成功
        users = User.objects.filter(uphone = uphone,upwd=upwd)
        if users:
        # 登录成功：先存进session
            request.session['uid']=users[0].id
            request.session['uphone']=uphone
        # 声明响应对象:从哪来 回哪去
            url = request.COOKIES.get('url','/')
            resp = redirect(url)
            # 将url从cookies中删除
            if 'url' in request.COOKIES:
                resp.delete_cookie('url')
            # resp = HttpResponse('登录成功')
            # 判断是否存进cookies
            if  'isSaved' in request.POST:

                expire = 60*60*24*90
                resp.set_cookie('uid',users[0].id,expire)
                resp.set_cookie('uphone', uphone, expire)

            return resp
        # 判断是否存进cookie

        else:
        #     登录失败
            form = LoginFrom()
            return HttpResponse('账号或密码错误')

    # return HttpResponse('ok')

def register_views(request):
    # 判断是get 还是post请求
    if request.method == 'GET':

        return render(request,'register.html')
    else:
#         验证手机号在数据库是否存在
        uphone = request.POST['uphone']
        # users = User.objects.filter(uphone=uphone)
        # if users:
        #     errMsg = '手机号码已经存在'
        #     return render(request,'register.html',locals())
#         插入数据库

        upwd = request.POST['upwd']
        uname = request.POST['uname']
        uemail = request.POST['uemail']
        user = User()
        user.uphone = uphone
        user.upwd = upwd
        user.uname = uname
        user.uemail = uemail
        user.save()
        # 取出user中的id和uphone的值保存进session
        request.session['uid']=user.id
        request.session['uphone']=user.uphone
        return HttpResponse('注册成功')

# 检查手机号是否被注册过
def check_uphone_views(request):
#     接收前端传递过来的数据 - uphone
    uphone = request.GET['uphone']
    users = User.objects.filter(uphone=uphone)
    if users:
        status = 1
        msg = '手机号码已经存在'
    else:
        status = 0
        msg = '通过'

    dic = {
        'status': status,
        'msg':msg,

    }
    return HttpResponse(json.dumps(dic))

def index_views(request):
    return render(request,'index.html')

# 检查session中是否有登录信息 如果有获取对应的数据的uname的值
def check_login_views(request):
    if 'uid' in request.session and 'uphone' in request.session:
        loginStatus = 1
#         通过uid的值获取对应的uname
        id = request.session['uid']
        uname = User.objects.get(id=id).uname
        dic = {
            'loginStatus':loginStatus,
            'uname':uname
        }
        return HttpResponse(json.dumps(dic))
    else:
        dic = {
            'loginStatus':0
        }
        return HttpResponse(json.dumps(dic))
#     退出
def logout_views(request):
    # 判断session是否有登录信息 有的话则删
    if 'uid' in request.session and 'uphone' in request.session:
        del request.session['uid']
        del request.session['uphone']
#         构建一个响应对象:哪发的退出请求 则返回去哪
        url = request.META.get('HTTP_REFERER','/')
        resp = HttpResponseRedirect(url)
#         判断cookies是否有登录信息有的话删除
        if 'uid' in request.COOKIES and 'uphone' in request.COOKIES:
            resp.delete_cookie('uid')
            resp.delete_cookie('uphone')
        return resp
    return redirect('/')
# 加载所有的商品类型以及对应的每个类型下的前10条数据
def type_goods_views(request):
    all_list=[]
    # 加载所有的商品类型
    types = GoodsType.objects.all()
    for type in types:
        type_json=json.dumps(type.to_dict())
    #     获取type类型下的最新的10条数据
        g_list = type.goods_set.filter(isActive=True).order_by('-id')[0:10]
    #     将g_list转换为json
        g_list_json = serializers.serialize('json',g_list)
        print(g_list_json)
        dic = {
            'type':type_json,
            'goods':g_list_json,
        }
        all_list.append(dic)
    return HttpResponse(json.dumps(all_list))
# 将商品添加至购物车 更新现有的商品数量
def add_acrt_views(request):
    # 获取商品ID,获取用户ID，购买数量默认为1
    good_id = request.GET['gid']
    user_id = request.session['uid']
    ccount = 1
#     查看购物车中是否有购买的商品
    cart_list = CartInfo.objects.filter(user_id=user_id,goods_id=good_id);
    if cart_list:
        # 已经有相同的商品,更新商品数量
        cartInfo = cart_list[0]
        cartInfo.ccount=cartInfo.ccount+ccount
        cartInfo.save()
        dic={
            'status':1,
            'statusText':'更新数量成功',

        }
    else:
#         没有对应的用户以及对应的商品
        cartInfo = CartInfo()
        cartInfo.user_id = user_id
        cartInfo.goods_id = good_id
        cartInfo.ccount = ccount
        cartInfo.save()
        dic = {
                'status':1,
                'statusText':'添加购物车成功',
        }
    return HttpResponse(json.dumps(dic))

def cart_info(request):
    return render(request,'cart.html')
