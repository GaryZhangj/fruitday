from django import forms
from .models import *

class LoginFrom(forms.ModelForm):
    class Meta:
        # 指定关联的Model
        model = User
        # 指定要显示的控件
        fields = ['uphone','upwd']
        # 指定每个控件的对应label
        labels = {

            'uphone': '手机号',
            'upwd': '密码',
        }
        #         指定小部件
        widgets = {
            'upwd': forms.PasswordInput(attrs={
                'class':'form-control',
                'placeholder':'请输入密码'
            }),
            'uphone': forms.TextInput(attrs={
                'class':"form-control"
            })
        }
