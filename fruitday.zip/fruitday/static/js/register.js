$(function(){
//        表示手机号是否被注册过的状态值
//        var registStatus = 1;
        window.registStatus = 1;
//    1.为uphone控件绑定blur事件
    $("input[name='uphone']").blur(function(){
//    如果文本框内没有任何东西则返回
        if($(this).val().trim().length == 0)
            return;
//        和文本框内有数据发送ajax请求判断数据是否存在
    $.get('/check_uphone/',{'uphone':$(this).val()},function(data){
                $("#uphone-tip").html(data.msg);
//                为regisStatus赋值以便提交表单时使用
                window.registStatus = data.status;
                console.log(data.status);
    },'json');

    });
//    2.为#formReg表单元素绑定submit事件
    $("#formReg").submit(function(){
//        判断registStatus的值 决定表单是否要提交
        if(window.registStatus == 1)
            return false;
        return true;
    });
});